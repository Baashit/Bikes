
  # Bike Website

  This is a code bundle for Bike Website. The original project is available at https://www.figma.com/design/UeXEAYpxN9EDS7BcrUxtCi/Bike-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  