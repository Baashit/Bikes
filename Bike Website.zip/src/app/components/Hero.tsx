import { ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-orange-50 to-orange-100 py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl mb-6">
              Ride Into Your Next Adventure
            </h1>
            <p className="text-lg text-gray-700 mb-8">
              Discover premium bikes engineered for performance, comfort, and style. Whether you're commuting or conquering trails, we've got the perfect ride for you.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="bg-orange-600 text-white px-8 py-3 rounded-lg hover:bg-orange-700 transition-colors flex items-center gap-2">
                Shop Now
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-orange-600 text-orange-600 px-8 py-3 rounded-lg hover:bg-orange-50 transition-colors">
                Learn More
              </button>
            </div>
          </div>
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1571333250630-f0230c320b6d?w=800&h=600&fit=crop"
              alt="Premium mountain bike"
              className="rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
