import { BikeIcon, Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <BikeIcon className="h-8 w-8 text-orange-600" />
              <span className="font-semibold text-xl text-white">CycleHub</span>
            </div>
            <p className="text-sm mb-4">
              Your trusted destination for premium bicycles and cycling accessories.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-orange-600 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-orange-600 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-orange-600 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-orange-600 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-orange-600 transition-colors">Mountain Bikes</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">Road Bikes</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">Electric Bikes</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">Accessories</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-orange-600 transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">Shipping Info</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">Returns</a></li>
              <li><a href="#" className="hover:text-orange-600 transition-colors">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white mb-4">Newsletter</h4>
            <p className="text-sm mb-4">Subscribe for exclusive deals and cycling tips.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 px-4 py-2 rounded-lg bg-gray-800 border border-gray-700 focus:outline-none focus:border-orange-600 text-sm"
              />
              <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors text-sm">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-sm">
          <p>&copy; 2026 CycleHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
