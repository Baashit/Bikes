import { BikeIcon, Menu, Search, ShoppingCart, User } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <BikeIcon className="h-8 w-8 text-orange-600" />
              <span className="font-semibold text-xl">CycleHub</span>
            </div>
            <nav className="hidden md:flex gap-6">
              <a href="#" className="text-sm hover:text-orange-600 transition-colors">Bikes</a>
              <a href="#" className="text-sm hover:text-orange-600 transition-colors">Accessories</a>
              <a href="#" className="text-sm hover:text-orange-600 transition-colors">Services</a>
              <a href="#" className="text-sm hover:text-orange-600 transition-colors">About</a>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <button className="hidden md:block p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <User className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute top-0 right-0 bg-orange-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
            </button>
            <button className="md:hidden p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
