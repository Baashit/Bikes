import { Shield, Truck, Wrench, Award } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Lifetime Warranty',
    description: 'All bikes come with comprehensive lifetime warranty coverage'
  },
  {
    icon: Truck,
    title: 'Free Shipping',
    description: 'Free delivery on all orders over $500 nationwide'
  },
  {
    icon: Wrench,
    title: 'Expert Service',
    description: 'Professional assembly and maintenance services available'
  },
  {
    icon: Award,
    title: 'Quality Certified',
    description: 'Every bike meets international safety and quality standards'
  }
];

export function Features() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="bg-orange-100 p-4 rounded-full mb-4">
                <feature.icon className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-lg mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
