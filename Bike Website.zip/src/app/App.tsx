import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { BikeCard } from './components/BikeCard';
import { Features } from './components/Features';
import { Footer } from './components/Footer';

const featuredBikes = [
  {
    id: 1,
    name: 'Trail Blazer Pro',
    category: 'Mountain',
    price: 2499,
    image: 'https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=600&h=400&fit=crop',
    rating: 5
  },
  {
    id: 2,
    name: 'Urban Commuter X',
    category: 'City',
    price: 899,
    image: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600&h=400&fit=crop',
    rating: 4
  },
  {
    id: 3,
    name: 'Road Racer Elite',
    category: 'Road',
    price: 3299,
    image: 'https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?w=600&h=400&fit=crop',
    rating: 5
  },
  {
    id: 4,
    name: 'E-Cruiser 3000',
    category: 'Electric',
    price: 1899,
    image: 'https://images.unsplash.com/photo-1559348349-86f1f65817fe?w=600&h=400&fit=crop',
    rating: 5
  },
  {
    id: 5,
    name: 'Gravel Explorer',
    category: 'Gravel',
    price: 2199,
    image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=600&h=400&fit=crop',
    rating: 4
  },
  {
    id: 6,
    name: 'Kids Adventure',
    category: 'Kids',
    price: 399,
    image: 'https://images.unsplash.com/photo-1502336421436-d3b93f7c7c83?w=600&h=400&fit=crop',
    rating: 5
  }
];

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main className="flex-1">
        <Hero />
        <Features />

        <section className="py-16 container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">Featured Bikes</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore our handpicked selection of premium bicycles, carefully chosen for quality, performance, and value.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredBikes.map((bike) => (
              <BikeCard key={bike.id} {...bike} />
            ))}
          </div>
        </section>

        <section className="py-16 bg-gradient-to-r from-orange-600 to-orange-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl mb-4">Ready to Start Your Journey?</h2>
            <p className="text-lg mb-8 text-orange-100 max-w-2xl mx-auto">
              Join thousands of satisfied cyclists who have found their perfect ride with us.
            </p>
            <button className="bg-white text-orange-600 px-8 py-3 rounded-lg hover:bg-orange-50 transition-colors">
              Browse All Bikes
            </button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}